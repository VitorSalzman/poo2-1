

Exerc�cio - m�todo f�brica 

Altere a classe FabricaDeNotificacoes e complete o m�todo. 
Altere a classe SimpleSlickGame para passar a usar o seu novo m�todo.

''
public Image criarImagensNotificacao(String tipo) {        
        //gameover
        //ganhou   
        return null;
    }
''