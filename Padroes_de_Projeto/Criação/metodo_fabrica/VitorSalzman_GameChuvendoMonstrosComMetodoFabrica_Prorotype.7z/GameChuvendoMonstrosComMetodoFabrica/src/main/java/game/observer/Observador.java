
package game.observer;

/**
 *
 * @author felipe
 */
public interface Observador   {
    
    public void update(Observavel ob);    
}
